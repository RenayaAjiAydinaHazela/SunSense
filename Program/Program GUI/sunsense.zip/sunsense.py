import tkinter as tk
from tkinter import ttk
from tkinter import scrolledtext
import time
import random
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
from matplotlib.figure import Figure

class SmartDryingApp:
    def __init__(self, root):
        self.root = root
        self.root.title("SUNSENSE SMART Drying Rack")
        self.root.geometry("700x550")
        self.root.configure(bg="#f7f7f7")

        self.temp = 30
        self.humidity = 85
        self.light = "Terang"
        self.rain = "Tidak Hujan"

        self.weather_icon = "🌤"
        self.weather_desc = "Cerah"

        self.notebook = ttk.Notebook(self.root)
        self.notebook.pack(expand=1, fill='both')

        self.home_tab = tk.Frame(self.notebook, bg="#f7f7f7")
        self.graph_tab = tk.Frame(self.notebook, bg="#f7f7f7")
        self.raw_data_tab = tk.Frame(self.notebook, bg="#f7f7f7")

        self.notebook.add(self.home_tab, text="🏠 Home")
        self.notebook.add(self.graph_tab, text="📊 Grafik")
        self.notebook.add(self.raw_data_tab, text="📄 Raw Data")

        self.setup_home()
        self.setup_graph()
        self.setup_raw_data()

        self.update_time()
        self.simulate_sensor_data()

    def setup_home(self):
        tk.Label(self.home_tab, text="SUNSENSE SMART Drying Rack", font=("Segoe UI", 16, "bold"), bg="#f7f7f7").pack(pady=(10, 0))
        self.time_label = tk.Label(self.home_tab, text="", font=("Segoe UI", 24), bg="#f7f7f7")
        self.time_label.pack()

        self.icon_label = tk.Label(self.home_tab, text=self.weather_icon, font=("Segoe UI", 30), bg="#f7f7f7")
        self.icon_label.pack()

        self.desc_label = tk.Label(self.home_tab, text=self.weather_desc, font=("Segoe UI", 12), bg="#f7f7f7")
        self.desc_label.pack()

        grid_frame = tk.Frame(self.home_tab, bg="#f7f7f7")
        grid_frame.pack(pady=20)

        self.temp_label = self.create_data_box(grid_frame, "Temperatur", f"{self.temp} °C", 0, 0)
        self.humidity_label = self.create_data_box(grid_frame, "Kelembaban", f"{self.humidity} %", 0, 1)
        self.light_label = self.create_data_box(grid_frame, "Cahaya", self.light, 1, 0)
        self.rain_label = self.create_data_box(grid_frame, "Hujan", self.rain, 1, 1)

    def create_data_box(self, parent, title, value, row, col):
        box = tk.Frame(parent, bg="white", bd=1, relief="solid")
        box.grid(row=row, column=col, padx=15, pady=15, ipadx=20, ipady=10)
        tk.Label(box, text=title, font=("Segoe UI", 11, "bold"), bg="white").pack()
        label = tk.Label(box, text=value, font=("Segoe UI", 12), bg="white")
        label.pack()
        return label

    def setup_graph(self):
        self.fig = Figure(figsize=(6, 4), dpi=100)
        self.ax = self.fig.add_subplot(111)
        self.canvas = FigureCanvasTkAgg(self.fig, master=self.graph_tab)
        self.canvas.get_tk_widget().pack()

        self.temp_data = []
        self.hum_data = []
        self.time_points = []

    def setup_raw_data(self):
        self.text_area = scrolledtext.ScrolledText(self.raw_data_tab, wrap=tk.WORD, font=("Consolas", 10))
        self.text_area.pack(expand=True, fill='both')

    def update_time(self):
        now = time.strftime("%H:%M:%S")
        self.time_label.config(text=now)
        self.root.after(1000, self.update_time)

    def simulate_sensor_data(self):
        self.temp = round(random.uniform(28, 34), 1)
        self.humidity = round(random.uniform(70, 90), 1)
        self.light = random.choice(["Terang", "Gelap"])
        self.rain = random.choice(["Tidak Hujan", "Hujan"])

        self.weather_icon = "🌤" if self.light == "Terang" else "🌙"
        self.weather_desc = "Cerah" if self.light == "Terang" else "Gelap"

        self.icon_label.config(text=self.weather_icon)
        self.desc_label.config(text=self.weather_desc)

        self.temp_label.config(text=f"{self.temp} °C")
        self.humidity_label.config(text=f"{self.humidity} %")
        self.light_label.config(text=self.light)
        self.rain_label.config(text=self.rain)

        now = time.strftime("%H:%M:%S")
        self.text_area.insert(tk.END, f"[{now}] Temp: {self.temp} °C, Humidity: {self.humidity} %, Light: {self.light}, Rain: {self.rain}\n")
        self.text_area.yview(tk.END)

        self.time_points.append(now)
        self.temp_data.append(self.temp)
        self.hum_data.append(self.humidity)

        if len(self.time_points) > 10:
            self.time_points.pop(0)
            self.temp_data.pop(0)
            self.hum_data.pop(0)

        self.ax.clear()
        self.ax.plot(self.time_points, self.temp_data, label="Temp (°C)", color="orange")
        self.ax.plot(self.time_points, self.hum_data, label="Humidity (%)", color="blue")
        self.ax.set_title("Grafik Sensor")
        self.ax.set_ylabel("Nilai")
        self.ax.set_xlabel("Waktu")
        self.ax.legend()
        self.ax.tick_params(axis='x', rotation=45)
        self.canvas.draw()

        self.root.after(3000, self.simulate_sensor_data)


if __name__ == '__main__':
    root = tk.Tk()
    app = SmartDryingApp(root)
    root.mainloop()
